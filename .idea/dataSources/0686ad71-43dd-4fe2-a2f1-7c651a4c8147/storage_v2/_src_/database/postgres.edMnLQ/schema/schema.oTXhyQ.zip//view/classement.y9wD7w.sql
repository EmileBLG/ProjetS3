create view classement (equipe_id, equipe_nom, division_id, sport_id, victoire, defaite, pm, pc) as
SELECT equipe.equipe_id,
       equipe.equipe_nom,
       equipe.division_id,
       equipe.sport_id,
       equipe.victoire,
       equipe.defaite,
       equipe.pm,
       equipe.pc
FROM schema.equipe;

alter table classement
    owner to postgres;

