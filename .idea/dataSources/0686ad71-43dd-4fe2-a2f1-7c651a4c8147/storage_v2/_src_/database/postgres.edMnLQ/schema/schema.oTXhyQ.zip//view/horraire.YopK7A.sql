create view horraire
            (match_id, heure, endroit, equipe1, equipe2, resultatequipe1, resultatequipe2, equipe_id, equipe_nom,
             division_id, sport_id, victoire, defaite, pm, pc)
as
SELECT a.match_id,
       a.heure,
       a.endroit,
       a.equipe1,
       a.equipe2,
       a.resultatequipe1,
       a.resultatequipe2,
       e.equipe_id,
       e.equipe_nom,
       e.division_id,
       e.sport_id,
       e.victoire,
       e.defaite,
       e.pm,
       e.pc
FROM schema.match a
         JOIN schema.equipe e ON e.equipe_id = a.equipe1;

alter table horraire
    owner to postgres;

